#include "ui.h"
#include <cmath>
#include <windows.h>
#include <chrono>
#include <thread>

namespace Tmpl8 {

	class Player;

	const int UI::M_GAME_OVER_BANNER_WIDTH = 288;
	const int UI::M_GAME_OVER_BANNER_HEIGHT = 288;
	const int UI::M_DIGIT_X = 157;
	const int UI::M_DIGIT_Y = 140;
	const int UI::M_DIGITS_WIDTH = 7;
	const int UI::M_DIGITS_HEIGHT = 12;

	//the game state is 1 by default which is the starting screen
	int UI::m_GameState = 1;


	//constructor
	UI::UI(int borderRestrictionX, int borderRestrictionY, int doubleDigit, int singleDigit) :
		m_BorderRestrictionX(borderRestrictionX), m_BorderRestrictionY(borderRestrictionY), m_DoubleDigit(doubleDigit), m_SingleDigit(singleDigit),
		background(new Surface("assets/background.png"), 1), 
		healthBar(new Surface("assets/HealthBar.png"), 11), 
		gameOverBanner(new Surface("assets/GameOverBannerBlank.png"), 1), 
		singleDigits(new Surface("assets/Digits.png"), 10), doubleDigits(new Surface("assets/Digits.png"), 10),
		OpeningBanner(new Surface("assets/GoblinSlayerOpeningBanner.png"), 1)
		
	{
	}

	//destructor
	UI::~UI() {
	}

	//health bar is actually a sprite with different frames being set depending on player health
	void UI::UpdateHealthBar(Sprite& healthBar, Player& player) {
		float healthBarFrameFloat = player.GetCurrentHealth() / 10.0f;
		int HealthbarFrame = static_cast<int>(std::floor(healthBarFrameFloat));
		if (HealthbarFrame < 10 && HealthbarFrame >= 0) {
			healthBar.SetFrame(HealthbarFrame + 1);
		}
		else if (player.GetCurrentHealth() <= 0) {
			healthBar.SetFrame(0);
		}
		
	}

	void UI::DisplayGameOver(Surface* gameScreen, Player& player) {
		
			
				gameScreen->Clear(0);
				int bannerX = gameScreen->GetWidth() / 2 - M_GAME_OVER_BANNER_WIDTH / 2;
				int bannerY = gameScreen->GetHeight() / 2 - M_GAME_OVER_BANNER_HEIGHT / 2;
				int digit1X = bannerX + M_DIGIT_X;
				int digit1Y = bannerY + M_DIGIT_Y;
				int digit2X = digit1X + M_DIGITS_WIDTH;
				int digit2Y = digit1Y;

				background.Draw(gameScreen, 0, 0);
				gameOverBanner.Draw(gameScreen, bannerX, bannerY);

				//sets the players score using a sprite for both digits
				SetDigitFrames(player);
				doubleDigits.Draw(gameScreen, digit1X, digit1Y);
				singleDigits.Draw(gameScreen, digit2X, digit2Y);

				if (GetAsyncKeyState(VK_SPACE)) {
					std::this_thread::sleep_for(std::chrono::milliseconds(500));
					m_GameState = 1;
				}
			
			
	}

	void UI::StartGame(Surface* gameScreen, Player& player) {
		
		gameScreen->Clear(0);
		OpeningBanner.Draw(gameScreen,0,0);
		if (GetAsyncKeyState(VK_SPACE)) {
			m_GameState = 2;
			std::this_thread::sleep_for(std::chrono::milliseconds(500));
		}
		
	}


	void UI::SetDigitFrames(Player& player) {
		singleDigits.SetFrame(player.m_KillCountSingleDigit);
		doubleDigits.SetFrame(player.m_KillCountDoubleDigit);
	}

		

	void UI::SetBorderRestrictionX(int distanceX) {
		m_BorderRestrictionX = distanceX;
	}

	int UI::GetBorderRestrictionX() {
		return m_BorderRestrictionX;
	}

	void UI::SetBorderRestrictionY(int distanceY) {
		m_BorderRestrictionY = distanceY;
	}

	int UI::GetBorderRestrictionY() {
		return m_BorderRestrictionY;
	}

}

