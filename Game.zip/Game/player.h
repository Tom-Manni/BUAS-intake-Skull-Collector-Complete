#pragma once
#include <string>
#include <algorithm>
#include <vector>
#include "game.h"
#include "surface.h"
#include "attack.h"
#include "object.h"
#include "enemy.h"
#include "ui.h"


namespace Tmpl8 {
	class Enemy;
	class UI;
	class Object;
	class Attack;
	class Sprite;

	class Player {
	public:
		Player(int imageHeight = 64, int imageWidth = 64, int frame = 0, int attackMovementDirection = 1, int speed = 3,
			std::vector <int> bashLocation = { 0,0 }, std::vector<int> location = {400, 256}, std::vector <int> swipeLocation = { 0,0 },
			bool isSpawned = 0, int currentWalkFrame = 0, int currentIdleFrame = 0, int currentBashLeftFrame = 0, int currentBashRightFrame = 0,
			int currentSwipeLeftFrame = 0, int currentSwipeRightFrame = 0, int currentDeathFrame = 0,
			bool isDead = 1, bool isAttackColliding = 0, int spriteOffsetX = 64, int spriteOffsetY = 64,
			float currentHealth = 100.0f, float maxHealth = 100.0f, float drainRate = 20.0f, float drainModifier = 1.0f,
			bool m_IsAnimationPlaying = 0, bool m_IsWalking = 0);
		~Player();

		//functions
		void SpawnIfNotSpawned(Surface* gameScreen, int x, int y);

		void CheckPlayerMoveInput(Surface* gameScreen, UI& background, float deltaTime);
		void CheckPlayerAttackInput(Surface* gameScreen, std::vector<Object*> bushes, Enemy& enemy, UI& baseUI);

		void BashLeft(Surface* gameScreen, std::vector<Object*> bushes, Enemy& enemy, UI& baseUI);
		void BashRight(Surface* gameScreen, std::vector<Object*> bushes, Enemy& enemy, UI& baseUI);
		void SwipeRight(Surface* gameScreen, Enemy& enemy, UI& baseUI);
		void SwipeLeft(Surface* gameScreen, Enemy& enemy, UI& baseUI);

		void DrainHealth(float deltaTime, UI& baseUI);
		void RegainHealth();
		void Die();

		void ResetStats();
		void ResetPlayer();

		bool CheckBushAttackCollision(Object* bush);
		bool CheckSwipeEnemyCollision(Enemy& enemy);

		

		void IncreaseKillCount();

		//animation functions
		void ProgressAllPlayerAnimations(Surface* gameScreen);
		void ProgressWalkAnimation();
		void ProgressIdleAnimation();

		void StartBashLeftAnimation(); 
		void ProgressBashLeftAnimation(Surface* gameScreen);

		void StartBashRightAnimation();
		void ProgressBashRightAnimation(Surface* gameScreen);

		void StartSwipeLeftAnimation();
		void ProgressSwipeLeftAnimation(Surface* gameScreen);

		void StartSwipeRightAnimation();
		void ProgressSwipeRightAnimation(Surface* gameScreen);

		void StartDeathAnimation();
		void ProgressDeathAnimation();

		

		//setters and getters
		void SetLocation(int x, int y);
		std::vector <int> GetLocation();

		void SetLeftBashLocation(int playerLocationX, int playerLocationY);
		std::vector <int> GetLeftBashLocation();

		void SetRightBashLocation(int playerLocationX, int playerLocationY);
		std::vector <int> GetRightBashLocation();

		void SetLeftSwipeLocation(int playerLocationX, int playerLocationY);
		std::vector <int> GetLeftSwipeLocation();

		void SetRightSwipeLocation(int playerLocationX, int playerLocationY);
		std::vector <int> GetRightSwipeLocation();

		void SetCurrentHealth(float health);
		float GetCurrentHealth();

		void SetMaxHealth(float health);
		float GetMaxHealth();

		void SetIsDead(bool isHit);
		bool GetIsDead();

		void SetIsAttackColliding(bool isAttackColliding);
		bool GetIsAttackColliding();

		static Player* playerPrt;
		Attack attack1;
		Sprite player;

		static int m_KillCountDoubleDigit;
		static int m_KillCountSingleDigit;

		static const int VK_X;
		static const int VK_C;

		static const int M_TOTAL_IDLE_FRAMES;
		static const int M_IDLE_LEFT_STARTING_FRAME;
		static const int M_IDLE_RIGHT_STARTING_FRAME;


		static const int M_TOTAL_WALK_FRAMES;
		static const int M_WALKLEFT_STARTING_FRAME;
		static const int M_WALKRIGHT_STARTING_FRAME;

		static const int M_TOTAL_BASH_FRAMES;
		static const int M_BASH_LEFT_STARTING_FRAME;
		static const int M_BASH_RIGHT_STARTING_FRAME;

		static const int M_TOTAL_SWIPE_FRAMES;
		static const int M_SWIPE_LEFT_STARTING_FRAME;
		static const int M_SWIPE_RIGHT_STARTING_FRAME;

		static const int M_TOTAL_DEATH_FRAMES;
		static const int M_DEATH_STARTING_FRAME;

		static const float M_BASE_DRAINRATE;
		

	

	private:

		bool m_IsAnimationPlaying;
		bool m_IsWalking;

		int m_CurrentWalkFrame;
		int m_CurrentIdleFrame;
		int m_CurrentBashLeftFrame;
		int m_CurrentBashRightFrame;
		int m_CurrentSwipeLeftFrame;
		int m_CurrentSwipeRightFrame;
		int m_CurrentDeathFrame;

		int m_Speed;
		int m_Frame;
		int m_AttackMovementDirection;

		bool m_IsSpawned;
		bool m_IsDead;
		bool m_IsAttackColliding;

		std::vector<int> m_SpawnLocation;
		std::vector<int> m_Location;
		std::vector <int> m_BashLocation;
		std::vector <int> m_SwipeLocation;

		int m_ImageHeight;
		int m_ImageWidth;
		int m_SpriteOffsetX;
		int m_SpriteOffsetY;

		float m_MaxHealth;
		float m_CurrentHealth;
		float m_DrainRate;
		float m_DrainModifier;
		
		

	};
}