#include <vector>
#include <stdlib.h>
#include <windows.h>
#include "game.h"
#include "surface.h"
#include "object.h"
#include "enemy.h"

#include <iostream>




namespace Tmpl8 {

	std::vector<Object*> Object::bushesPtr;

	//constructor
	Object::Object(int imageHeight, int imageWidth, int spawnTestX, int spawnTestY, int frame, 
		std::vector<int> location, std::vector<int> spawnTestLocation, bool isHit, bool isColliding) :
		m_ImageHeight(imageHeight), m_ImageWidth(imageWidth), m_SpawnTestX(spawnTestX),m_SpawnTestY(spawnTestY), m_Frame(frame), 
		m_Location(location), m_SpawnTestLocation(spawnTestLocation), m_IsHit(isHit), m_IsColliding(isColliding),
		bush(new Surface("assets/bush.png"), 1)
	{
	}

	//destructor
	Object::~Object() {
	}





	//draws all bushes. Spawns them if that hasn't happened yet
	void Object::DrawAll(Surface* gameScreen, UI& baseUI) {
		for (int i = 0; i < bushesPtr.size(); i++) {
			if (bushesPtr[i]->GetIsHit() == true) {
				bushesPtr[i]->Spawn(gameScreen, baseUI);
			}

			else {
				bushesPtr[i]->bush.Draw(gameScreen, bushesPtr[i]->GetLocation()[0] - bushesPtr[i]->m_ImageWidth/2, 
					bushesPtr[i]->GetLocation()[1]- bushesPtr[i]->m_ImageHeight/2);
			}
		}
	}

	
	//spawns an object on a random location on screen. tries rerolling 10 times to avoid collisions
	void Object::Spawn(Surface* gameScreen, UI& baseUI)
	{
		//set const screenheight and width where you can draw legally
		const int screenX = (gameScreen->GetWidth() - m_ImageWidth - baseUI.GetBorderRestrictionX());
		const int screenY = (gameScreen->GetHeight() - m_ImageHeight - baseUI.GetBorderRestrictionY());

		//select a suitable locatoin before spawning, max attempts set to prevent infinite loop
		int attempts = 0;
		int maxAttempts = 10;
		while (attempts < maxAttempts) {
			//use a placeholder to test against
			m_SpawnTestX = rand() % screenX + baseUI.GetBorderRestrictionX();
			m_SpawnTestY = rand() % screenY +baseUI.GetBorderRestrictionY();

			m_SpawnTestLocation[0] = m_SpawnTestX;
			m_SpawnTestLocation[1] = m_SpawnTestY;

			const int screenXCenter = gameScreen->GetWidth()/2;
			const int screenYCenter = gameScreen->GetHeight()/2;
		
			if (CheckSpawnCollision(m_SpawnTestLocation) == false) {
				SetLocation(m_SpawnTestX, m_SpawnTestY);
				break; // Exit loop if location is valid
			}
			
			attempts++;
		}
			
		m_IsHit = false;
	}

	//checks for spawn collision of other bushes
	bool Object::CheckSpawnCollision(std::vector<int> testLocation) {
		for (int i = 0; i < bushesPtr.size(); i++) {
			// Check for x collision
			bool xCollision = testLocation[0] < bushesPtr[i]->GetLocation()[0] + bushesPtr[i]->m_ImageWidth &&
				testLocation[0] > bushesPtr[i]->GetLocation()[0];

			// Check for y collision
			bool yCollision = testLocation[1] < bushesPtr[i]->GetLocation()[1] + bushesPtr[i]->m_ImageHeight &&
				testLocation[1] > bushesPtr[i]->GetLocation()[1];

			// If both x and y collisions are true, set m_IsColliding to true and exit loop early
			if (xCollision && yCollision) {
				m_IsColliding = true;
				return true;
			}
		}

		// If no collision
		m_IsColliding = false;
		return false;
	}



	//returns object centerpoint coordinate
	std::vector<int> Object::GetCenter() 
	{
		int centerX = m_Location[0] + (m_ImageWidth / 2);
		int centerY = m_Location[1] + (m_ImageHeight / 2);
		std::vector <int> centerPoint = { centerX, centerY };

		return centerPoint;
	}


	//Getters and setters
	void Object::SetLocation(int x, int y) {
		m_Location[0] = x;
		m_Location[1] = y;
	}
	std::vector <int> Object::GetLocation() {
		return m_Location;
	}

	void Object::SetFrame(int frame) {
		m_Frame = frame;
	}
	int Object::GetFrame() {
		return m_Frame;
	}

	void Object::SetIsHit(bool isHit) {
		m_IsHit = isHit;
	}
	bool Object::GetIsHit() {
		return m_IsHit;
	}

	void Object::SetIsColliding(bool isColliding) {
		m_IsColliding = isColliding;
	}
	bool Object::GetIsColliding() {
		return m_IsColliding;
	}

}

