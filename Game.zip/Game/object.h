#pragma once
#include <string>
#include <algorithm>
#include <vector>
#include "game.h"
#include "surface.h"
#include "ui.h"

namespace Tmpl8 {

	class Human;
	class UI;

	class Object {
	public:
		Object(int imageHeight = 64, int imageWidth = 64, int spawnTestX = 0, int spawnTestY = 0, int frame = 0, 
			std::vector<int> location = { 100, 100 }, std::vector<int> spawnTestLocation = {0,0}, bool isHit = true, bool isColliding = 0);
		~Object();

		void Spawn(Surface* gameScreen, UI& baseUI);
		bool CheckSpawnCollision(std::vector<int> testLocation);


		static void DrawAll(Surface* gameScreen, UI& baseUI);

		//setters and getters
		void SetLocation(int x, int y);
		std::vector <int> GetLocation();

		void SetFrame(int frame);
		int GetFrame();

		void SetIsHit(bool isHit);
		bool GetIsHit();

		void SetIsColliding(bool isColliding);
		bool GetIsColliding();

		std::vector<int> GetCenter();

		int m_ImageHeight;
		int m_ImageWidth;
		std::vector<int> m_SpawnTestLocation;

		static std::vector<Object*> bushesPtr;
		

		Sprite bush;

	private:

		
		int m_SpawnTestX;
		int m_SpawnTestY;
		int m_Frame;
		bool m_IsHit;
		bool m_IsColliding;
		std::vector<int> m_Location;

	};
}