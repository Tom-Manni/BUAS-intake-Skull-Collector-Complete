How to play:
Bash bushes to reveal goblins, collect goblin skulls to keep your rage meter full.
The goblins will try to escape to the nearest exit.
if your rage meter runs out, the game is over.

Controls:
X = bash - destroys bushes and reveals enemies
C = Swipe - kills goblins and severs their skull
space = progress menu's
arrow keys = move


credits:

Art assets based on pixelfrog's tiny sword pack on https://pixelfrog-assets.itch.io/tiny-swords

Template, BUAS version https://www.buas.nl/games
IGAD/BUAS(NHTV)/UU - Jacco Bikker - 2006-2020




