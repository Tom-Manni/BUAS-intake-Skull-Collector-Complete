#pragma once
#include "game.h"
#include "surface.h"
#include "player.h"

namespace Tmpl8 {
	class Exit {
	public:

		static const int M_EXIT_WIDTH;
		static const int M_EXIT_HEIGHT;
		static const std::vector <int> M_EXIT_LEFT;
		static const std::vector <int> M_EXIT_RIGHT;
		static const std::vector <int> M_EXIT_TOP;
		static const std::vector <int> M_EXIT_BOTTOM;

	private:


	};
}
