#pragma once
#include "game.h"
#include "surface.h"
#include "player.h"

namespace Tmpl8 {
	class Player;
	class UI {
	public://check image heights and width
		UI(int borderRestrictionX = 50, int borderRestrictionY = 32, int doubleDigit = 0, int singleDigit = 0);
		~UI();

		Sprite background;
		Sprite healthBar;
		Sprite OpeningBanner;
		Sprite gameOverBanner;
		Sprite singleDigits;
		Sprite doubleDigits;

		void UpdateHealthBar(Sprite& healthBar, Player& player);
		void DisplayGameOver(Surface* gameScreen, Player& player);

		void StartGame(Surface* gameScreen, Player& player);

		void SetDigitFrames(Player& player);

		void SetBorderRestrictionX(int distanceX);
		int GetBorderRestrictionX();

		void SetBorderRestrictionY(int distanceY);
		int GetBorderRestrictionY();

		static const int M_GAME_OVER_BANNER_HEIGHT;
		static const int M_GAME_OVER_BANNER_WIDTH;
		static const int M_DIGITS_HEIGHT;
		static const int M_DIGITS_WIDTH;
		static const int M_DIGIT_X; //relative to banner location
		static const int M_DIGIT_Y; //^^
		

		static  int m_lineX;
		static int m_lineY;
		static  int m_GameState;

		int m_DoubleDigit;
		int m_SingleDigit;


	private:

		
		int m_BorderRestrictionX;
		int m_BorderRestrictionY;
	


	};
}