#include <vector>
#include <stdlib.h>
#include <windows.h>
#include "enemy.h"

#include <iostream>
namespace Tmpl8 {

	const int Enemy::M_TOTAL_WALK_FRAMES = 5;
	const int Enemy::M_WALK_LEFT_STARTING_FRAME = 19;
	const int Enemy::M_WALK_RIGHT_STARTING_FRAME = 13;
	

	const int Enemy::LEFT = 1;
	const int Enemy::RIGHT = 2;


	Enemy::Enemy(int imageHeight, int imageWidth, int frame, int speed, float invincibilitySecs, float iFrameTimer, 
		int lastMovementDirection, int currentWalkFrame, 
		std::vector<int> location, bool isHit, bool isAlive, bool isInvincible, int spriteOffsetX, int spriteOffsetY) :
		m_ImageHeight(imageHeight), m_ImageWidth(imageWidth), m_Frame(frame), m_Speed(speed),
		m_InvincibilitySecs(invincibilitySecs), m_IFrameTimer(iFrameTimer), 
		m_LastMovementDirection(lastMovementDirection), m_CurrentWalkFrame(currentWalkFrame),
		m_Location(location), m_IsHit(isHit), m_IsAlive(isAlive), m_IsInvincible(isInvincible),
		m_SpriteOffsetX(spriteOffsetX), m_SpriteOffsetY(spriteOffsetY), bomber(new Surface("assets/bomber.png"), 45)
	{
	}
	Enemy::~Enemy() {

	}

	//runs to the exit located in the enemies quadrant of the screen
	void Enemy::RunAway(Surface* gameScreen, float deltaTime, Player& playerReference)
	{
		if (m_IsAlive == true) {
			
			//Top
			if (CheckQuadrant(gameScreen) == 1) {
				if (m_Location[1] > Exit::M_EXIT_TOP[1]) {
					m_Location[1] -= m_Speed;
				}
				if (m_Location[0] > Exit::M_EXIT_TOP[0]) {
					m_Location[0] -= m_Speed;
					m_LastMovementDirection = LEFT;
				}
				else if (m_Location[0] < Exit::M_EXIT_TOP[0]) {
					m_Location[0] += m_Speed;
					m_LastMovementDirection = RIGHT;
				}

			}
			//Right
			else if (CheckQuadrant(gameScreen) == 2) {
				if (m_Location[0] < Exit::M_EXIT_RIGHT[0]) {
					m_Location[0] += m_Speed;
					m_LastMovementDirection = RIGHT;
				}
				if (m_Location[1] > Exit::M_EXIT_RIGHT[1]) {
					m_Location[1] -= m_Speed;
				}
				else if (m_Location[1] < Exit::M_EXIT_RIGHT[1]) {
					m_Location[1] += m_Speed;
				}
			}
			//Bottom
			else if (CheckQuadrant(gameScreen) == 3) {
				if (m_Location[1] < Exit::M_EXIT_BOTTOM[1]) {
					m_Location[1] += m_Speed;
				}
				if (m_Location[0] > Exit::M_EXIT_BOTTOM[0]) {
					m_Location[0] -= m_Speed;
					m_LastMovementDirection = LEFT;
				}
				else if (m_Location[0] < Exit::M_EXIT_BOTTOM[0]) {
					m_Location[0] += m_Speed;
					m_LastMovementDirection = RIGHT;
				}
			}
			//Left
			else if (CheckQuadrant(gameScreen) == 4) {

				if (m_Location[0] > Exit::M_EXIT_LEFT[0]) {
					m_Location[0] -= m_Speed;
					m_LastMovementDirection = LEFT;
				}
				if (m_Location[1] > Exit::M_EXIT_LEFT[1]) {
					m_Location[1] -= m_Speed;
				}
				else if (m_Location[1] < Exit::M_EXIT_LEFT[1]) {
					m_Location[1] += m_Speed;
				}

			}
		
			bomber.Draw(gameScreen, m_Location[0] - m_SpriteOffsetX - m_ImageWidth / 2, m_Location[1] - m_SpriteOffsetY - m_ImageWidth / 2);

			
		}
	

		Escape(gameScreen);
	}

	void Enemy::ProgressWalkAnimation() {
		
		if (m_CurrentWalkFrame < M_TOTAL_WALK_FRAMES) {
			m_CurrentWalkFrame += 1;
		}

		else if (m_CurrentWalkFrame >= M_TOTAL_WALK_FRAMES) {
			m_CurrentWalkFrame = 0;
			std::cout << "works\n";
		}

		if (m_LastMovementDirection == LEFT) {
			bomber.SetFrame(m_CurrentWalkFrame + M_WALK_LEFT_STARTING_FRAME);

		}
		else if (m_LastMovementDirection == RIGHT) {
			bomber.SetFrame(m_CurrentWalkFrame + M_WALK_RIGHT_STARTING_FRAME);

		}
	}

	void Enemy::Die() {
		SetIsAlive(false);
	}

	//checks if the enemy has reached an exit and then stops living. does not count towards player kills
	void Enemy::Escape(Surface* gameScreen) {
		bool escapeTop = m_Location[0] > Exit::M_EXIT_TOP[0] - Exit::M_EXIT_WIDTH / 2 && m_Location[0] < Exit::M_EXIT_TOP[0] + Exit::M_EXIT_WIDTH / 2 &&
			m_Location[1] <= Exit::M_EXIT_TOP[1];

		bool escapeRight = m_Location[1] > Exit::M_EXIT_RIGHT[1] - Exit::M_EXIT_WIDTH / 2 && m_Location[1] < Exit::M_EXIT_RIGHT[1] + Exit::M_EXIT_WIDTH / 2 &&
			m_Location[0] >= Exit::M_EXIT_RIGHT[0];;

		bool escapeBottom = m_Location[0] > Exit::M_EXIT_BOTTOM[0] - Exit::M_EXIT_WIDTH / 2 && m_Location[0] < Exit::M_EXIT_BOTTOM[0] + Exit::M_EXIT_WIDTH / 2 &&
			m_Location[1] >= Exit::M_EXIT_BOTTOM[1];

		bool escapeLeft = m_Location[1] > Exit::M_EXIT_LEFT[1] - Exit::M_EXIT_WIDTH / 2 && m_Location[1] < Exit::M_EXIT_LEFT[1] + Exit::M_EXIT_WIDTH / 2 &&
			m_Location[0] <= Exit::M_EXIT_LEFT[0];

		if (escapeTop || escapeRight || escapeBottom || escapeLeft) {
			m_IsAlive = false;
		}
	}

	void Enemy::ResetBomber() {
		m_IsHit = false;
		m_IsAlive = false;
	}
	

	//spawns enemy at bush location
	void Enemy::Spawn(Surface* gameScreen, Object* bush) {
		if (m_IsAlive == false) {
			m_IsAlive = true;
			m_Location[0] = bush->GetLocation()[0];
			m_Location[1] = bush->GetLocation()[1];

			bomber.Draw(gameScreen, m_Location[0] - m_SpriteOffsetX - m_ImageWidth / 2, m_Location[1] - m_SpriteOffsetY - m_ImageWidth / 2);
		}
		
	}


	int Enemy::CheckQuadrant(Surface* gameScreen) {
		//calculates 2 diagonal lines running from top left to bottom right, and from top right to bottom left 
		//this creates four quadrants that can be used to check enemy location for pathing to exit
		float Y1;
		float Y2;
		const float screenWidth = static_cast<float> (gameScreen->GetWidth());
		const float screenHeight = static_cast<float> (gameScreen->GetHeight());
		float playerX = static_cast<float> (m_Location[0]);
		float playerY = static_cast<float> (m_Location[1]);

		Y1 = playerX / screenWidth * screenHeight;
		Y2 = playerX / -screenWidth * screenHeight + screenHeight;
	
		bool isTop = playerY < Y1 && playerY < Y2;
		bool isRight = playerY < Y1 && playerY > Y2;
		bool isBottom = playerY > Y1 && playerY > Y2;
		bool isLeft = playerY > Y1 && playerY < Y2;
		

		if (isTop == true) { return 1; }//top
		else if (isRight == true) { return	2; }//right
		else if (isBottom == true) { return 3; }
		else if (isLeft == true) { return 4; }
		else { return 1; }

	}




	void Enemy::SetLocation(int x, int y) {
		m_Location[0] = x;
		m_Location[1] = y;
	}
	std::vector <int> Enemy::GetLocation() {
		return m_Location;
	}

	void Enemy::SetIsAlive(bool isAlive) {
		m_IsAlive = isAlive;
	}
	bool Enemy::GetIsAlive() {
		return m_IsAlive;
	}

	void Enemy::SetIsInvincible(bool isInvincible) {
		m_IsInvincible = isInvincible;
	}
	bool Enemy::GetIsInvincible() {
		return m_IsInvincible;
	}

	void Enemy::SetInvincibilitySecs(float invincibilitySecs) {
		m_InvincibilitySecs = invincibilitySecs;
	}
	float Enemy::GetInvincibilitySecs() {
		return m_InvincibilitySecs;
	}

	void Enemy::SetIFrameTimer(float iFrameTimer) {
		m_IFrameTimer = iFrameTimer;
	}
	float Enemy::GetIFrameTimer() {
		return m_IFrameTimer;
	}
}