#include <vector>
#include <stdlib.h>
#include <windows.h>

#include "player.h"
#include "game.h"
#include "surface.h"

#include "object.h"
#include "ui.h"

#include <iostream>




namespace Tmpl8 {


	Player* Player::playerPrt = new Player();
	int Player::m_KillCountSingleDigit = 0;
	int Player::m_KillCountDoubleDigit = 0;

	//data members for player inputs
	const int Player::VK_X = 0x58;
	const int Player::VK_C = 0x43;

	// data members for animations
	const int Player::M_TOTAL_IDLE_FRAMES = 4;
	const int Player::M_IDLE_LEFT_STARTING_FRAME = 7;
	const int Player::M_IDLE_RIGHT_STARTING_FRAME = 2;

	const int Player::M_TOTAL_WALK_FRAMES = 4;
	const int Player::M_WALKLEFT_STARTING_FRAME = 18;
	const int Player::M_WALKRIGHT_STARTING_FRAME = 13;

	const int Player::M_TOTAL_BASH_FRAMES = 3;
	const int Player::M_BASH_LEFT_STARTING_FRAME = 30;
	const int Player::M_BASH_RIGHT_STARTING_FRAME = 25;

	const int Player::M_TOTAL_SWIPE_FRAMES = 3;
	const int Player::M_SWIPE_LEFT_STARTING_FRAME = 41;
	const int Player::M_SWIPE_RIGHT_STARTING_FRAME = 36;

	const int Player::M_TOTAL_DEATH_FRAMES = 8;
	const int Player::M_DEATH_STARTING_FRAME = 58;

	const float Player::M_BASE_DRAINRATE = 20.0f;



	//constructor
	Player::Player(int imageHeight, int imageWidth, int frame, int attackMovementDirection,
		int speed, std::vector<int> bashLocation, std::vector<int> location, std::vector<int> swipeLocation,
		bool isSpawned, int currentWalkFrame, int currentIdleFrame, int currentBashLeftFrame, int currentBashRightFrame,
		int currentSwipeLeftFrame, int currentSwipeRightFrame, int currentDeathFrame,
		bool isDead, bool isAttackColliding, int spriteOffsetX,
		int spriteOffsetY, float currentHealth, float maxHealth, float drainRate, float drainModifier,
		bool isAnimationPlaying, bool isWalking) :
		m_ImageHeight(imageHeight), m_ImageWidth(imageWidth), m_Frame(frame), m_AttackMovementDirection(attackMovementDirection), m_Speed(speed),
		m_BashLocation(bashLocation), m_Location(location), m_SwipeLocation(swipeLocation), m_IsSpawned(isSpawned),
		m_CurrentWalkFrame(currentWalkFrame), m_CurrentIdleFrame(currentIdleFrame), m_CurrentBashLeftFrame(currentBashLeftFrame),
		m_CurrentBashRightFrame(currentBashRightFrame), m_CurrentSwipeLeftFrame(currentSwipeLeftFrame), m_CurrentSwipeRightFrame(currentSwipeRightFrame),
		m_CurrentDeathFrame(currentDeathFrame),
		m_IsDead(isDead),
		m_IsAttackColliding(isAttackColliding), m_SpriteOffsetX(spriteOffsetX), m_SpriteOffsetY(spriteOffsetY),
		m_CurrentHealth(currentHealth), m_MaxHealth(maxHealth), m_DrainRate(drainRate), m_DrainModifier(drainModifier),
		m_IsAnimationPlaying(isAnimationPlaying), m_IsWalking(isWalking),
		player(new Surface("assets/player.png"), 66)
	{
	}

	//destructor
	Player::~Player()
	{
	}


	//makes player alive and well, resets stats and player state
	void Player::SpawnIfNotSpawned(Surface* gameScreen, int x, int y)
	{
		if (m_IsSpawned == false) {
			m_IsSpawned = true;
			m_IsDead = false;
			player.Draw(gameScreen, m_Location[0] - (m_SpriteOffsetX + m_ImageWidth / 2), m_Location[1] - (m_SpriteOffsetY + m_ImageHeight / 2));
		}
	}

	//resets all the things that change of the course of the game
	void Player::ResetStats() { 
		m_KillCountSingleDigit = 0;
		m_KillCountDoubleDigit = 0;
	}

	void Player::ResetPlayer() {
		m_CurrentHealth = m_MaxHealth;
		m_DrainRate = M_BASE_DRAINRATE;

		m_Location = { 400, 256 };
	}

	void Player::DrainHealth(float deltaTime, UI& baseUI) {
		if (m_CurrentHealth > 0 && m_IsDead == false) {
			m_CurrentHealth -= m_DrainRate * (deltaTime / 1000);
			m_DrainRate += m_DrainModifier * (deltaTime/1000);
		}

		else {
			Die();
			StartDeathAnimation();
		}

	}

	void Player::RegainHealth() {
		m_CurrentHealth = m_MaxHealth;
	}

	void Player::Die() {
		m_IsDead = true;
		m_IsSpawned = false;
	}


	//Checks for movement and background borders size
	void Player::CheckPlayerMoveInput(Surface* gameScreen, UI& background, float deltaTime)
	{
		if (m_IsDead == false|| m_CurrentDeathFrame > 0) {
			int NX = m_Location[0], NY = m_Location[1];
			const int LEFT = 1;
			const int RIGHT = 2;

			//animations are integrated in this function. If a priority animation is playing like an attack or death, the player cannot move.
			//moving left or right also sets the direction in which the sprite faces and attacks
			if (GetAsyncKeyState(VK_LEFT) && m_IsAnimationPlaying == false) {
				if (NX - m_Speed >= background.GetBorderRestrictionX() + m_ImageWidth / 2) {
					m_Location[0] -= m_Speed;
					m_AttackMovementDirection = LEFT;
					//turns the player sprite without having to wait for animations to progress
					if (m_IsAnimationPlaying == false && m_AttackMovementDirection == LEFT) {
						player.SetFrame(m_CurrentWalkFrame + M_WALKLEFT_STARTING_FRAME);
					}
				}
			}
			if (GetAsyncKeyState(VK_RIGHT) && m_IsAnimationPlaying == false) {
				if (NX + m_Speed <= gameScreen->GetWidth() - background.GetBorderRestrictionX() - m_ImageWidth / 2) {
					m_Location[0] += m_Speed;
					m_AttackMovementDirection = RIGHT;
					//turns the player sprite without having to wait for animations to progress
					if (m_IsAnimationPlaying == false && m_AttackMovementDirection == RIGHT) {
						player.SetFrame(m_CurrentWalkFrame + M_WALKRIGHT_STARTING_FRAME);
					}
				}
			}
			if (GetAsyncKeyState(VK_UP) && m_IsAnimationPlaying == false) {
				if (NY - m_Speed >= (background.GetBorderRestrictionY())) {
					m_Location[1] -= m_Speed;
				}
			}
			if (GetAsyncKeyState(VK_DOWN) && m_IsAnimationPlaying == false) {
				if (NY + m_Speed <= gameScreen->GetHeight() - background.GetBorderRestrictionY() - m_ImageHeight / 2) {
					m_Location[1] += m_Speed;
				}
			}

			player.Draw(gameScreen, m_Location[0] - (m_SpriteOffsetX + m_ImageWidth / 2), m_Location[1] - (m_SpriteOffsetY + m_ImageHeight / 2));
		}
	}


	//uses the direction set by CheckMoveInput()
	void Player::CheckPlayerAttackInput(Surface* gameScreen, std::vector<Object*> bushes, Enemy& enemy, UI& baseUI) {
		const int LEFT = 1;
		const int Right = 2;
		if (m_AttackMovementDirection == 1) {
			BashLeft(gameScreen, bushes, enemy, baseUI);
			SwipeLeft(gameScreen, enemy, baseUI);
		}
		else if (m_AttackMovementDirection == 2) {
			BashRight(gameScreen, bushes, enemy, baseUI);
			SwipeRight(gameScreen, enemy, baseUI);
		}
	}


	//Checks for player Attacks
	void Player::BashLeft(Surface* gameScreen, std::vector<Object*> bushes, Enemy& enemy, UI& baseUI) {
		//the player can attack if no other priority animation is playing. Also keeps attacking as long as the animation is playing (current frame above 0)
		bool canAttack = m_IsAnimationPlaying == false || m_CurrentBashLeftFrame > 0;

		if (GetAsyncKeyState(VK_X) && m_IsDead == false && canAttack) {
			
			StartBashLeftAnimation();
		}

		if (m_CurrentBashLeftFrame > 0) { //hurtbox is up as long as animation is playing
			SetLeftBashLocation(GetLocation()[0], GetLocation()[1]);

			for (int i = 0; i < bushes.size(); i++) {
				if (CheckBushAttackCollision(bushes[i])) {
					if (enemy.GetIsAlive() == false) {
						enemy.Spawn(gameScreen, bushes[i]);
					}
					bushes[i]->Spawn(gameScreen, baseUI);
				}
			}
		}
	}

	void Player::BashRight(Surface* gameScreen, std::vector<Object*> bushes, Enemy& enemy, UI& baseUI) {
		//the player can attack if no other priority animation is playing. Also keeps attacking as long as the animation is playing (current frame above 0)
		bool canAttack = m_IsAnimationPlaying == false || m_CurrentBashRightFrame > 0;


		if (GetAsyncKeyState(VK_X) && m_IsDead == false && canAttack) {
			StartBashRightAnimation();
		}

		if (m_CurrentBashRightFrame > 0) { //hurtbox is up as long as animation is playing
			SetRightBashLocation(GetLocation()[0], GetLocation()[1]);

			for (int i = 0; i < bushes.size(); i++) {
				if (CheckBushAttackCollision(bushes[i])) {
					if (enemy.GetIsAlive() == false) {
						enemy.Spawn(gameScreen, bushes[i]);
					}
					bushes[i]->Spawn(gameScreen, baseUI);
				}
			}
		}
	}

	void Player::SwipeLeft(Surface* gameScreen, Enemy& enemy, UI& baseUI) {
		//the player can attack if no other priority animation is playing. Also keeps attacking as long as the animation is playing (current frame above 0)
		bool canAttack = m_IsAnimationPlaying == false || m_CurrentSwipeLeftFrame > 0;


		if (GetAsyncKeyState(VK_C) && m_IsDead == false && canAttack) {
			//play animation
			StartSwipeLeftAnimation();

		}

		if (m_CurrentSwipeLeftFrame > 0) { //hurtbox is up as long as animation is playing
			SetLeftSwipeLocation(GetLocation()[0], GetLocation()[1]);

			if (CheckSwipeEnemyCollision(enemy) && enemy.GetIsAlive()) {
				enemy.Die();
				IncreaseKillCount();
				RegainHealth();
			}
		}
	}
	//CHANGE THE GET AND SETS
	void Player::SwipeRight(Surface* gameScreen, Enemy& enemy, UI& baseUI) {
		//the player can attack if no other priority animation is playing. Also keeps attacking as long as the animation is playing (current frame above 0)
		bool canAttack = m_IsAnimationPlaying == false || m_CurrentSwipeRightFrame > 0;

		if (GetAsyncKeyState(VK_C) && m_IsDead == false && canAttack) {

			StartSwipeRightAnimation();

		}

		if (m_CurrentSwipeRightFrame > 0) { //hurtbox is up as long as animation is playing
			SetRightSwipeLocation(GetLocation()[0], GetLocation()[1]);

			if (CheckSwipeEnemyCollision(enemy) && enemy.GetIsAlive()) {
				enemy.SetIsAlive(false);
				IncreaseKillCount();
				RegainHealth();
			}
		}
		
	}

	//checks for attack collision with bushes
	bool Player::CheckBushAttackCollision(Object* bush) {
		bool xCollision = false;
		bool yCollision = false;

		//checks for x collision and sets to false if not true
		if ((GetLeftBashLocation()[0]) < bush->GetLocation()[0] + bush->m_ImageWidth &&
			(GetLeftBashLocation()[0] + attack1.m_AttackWidth) > bush->GetLocation()[0]) {
			xCollision = true;
		}
		else { xCollision = false; }

		//does the same for y collision
		if ((GetLeftBashLocation()[1]) < bush->GetLocation()[1] + bush->m_ImageHeight &&
			(GetLeftBashLocation()[1] + attack1.m_AttackHeight) > bush->GetLocation()[1]) {
			yCollision = true;
		}
		else {
			yCollision = false;
		}

		if (xCollision && yCollision) {
			m_IsAttackColliding = true;
		}
		else {
			m_IsAttackColliding = false;
		}

		return m_IsAttackColliding;
	}


	bool Player::CheckSwipeEnemyCollision(Enemy& enemy) {
		bool xCollision = false;
		bool yCollision = false;

		//checks for x collision
		if (GetLeftSwipeLocation()[0] < enemy.GetLocation()[0] + enemy.m_ImageWidth &&
			GetLeftSwipeLocation()[0] + attack1.m_AttackWidth > enemy.GetLocation()[0]) {
			xCollision = true;
		}
		else { xCollision = false; }

		//same for y collision
		if (GetLeftSwipeLocation()[1] < enemy.GetLocation()[1] + enemy.m_ImageHeight - enemy.m_SpriteOffsetY / 2 &&
			GetLeftSwipeLocation()[1] + attack1.m_AttackHeight > enemy.GetLocation()[1]) {
			yCollision = true;
		}
		else {
			yCollision = false;
		}

		if (xCollision && yCollision) {
			m_IsAttackColliding = true;
		}
		else {
			m_IsAttackColliding = false;
		}

		return m_IsAttackColliding;
	}

	void Player::IncreaseKillCount() {
		//when the killcount goes above 09, the single digit is set to 0 and the double to 1.
		//Since I am using a sprite for the numbers to get a certain font, the killcount is limited to 99 this way.
		m_KillCountSingleDigit++;
		if (m_KillCountSingleDigit > 9) {
			m_KillCountDoubleDigit++;
			m_KillCountSingleDigit = 0;
		}
	}




	//animation funcions
	void Player::ProgressAllPlayerAnimations(Surface* gameScreen) {
		ProgressWalkAnimation();
		ProgressIdleAnimation();

		ProgressBashLeftAnimation(gameScreen);
		ProgressBashRightAnimation(gameScreen);
		ProgressSwipeLeftAnimation(gameScreen);
		ProgressSwipeRightAnimation(gameScreen);
		ProgressDeathAnimation();
	}

	void Player::ProgressIdleAnimation() { //the lowest priority animation, only plays when the playing is standing still doing nothing
		bool isMoving = GetAsyncKeyState(VK_LEFT) || GetAsyncKeyState(VK_RIGHT) || GetAsyncKeyState(VK_UP) || GetAsyncKeyState(VK_DOWN);
		const int LEFT = 1;
		const int RIGHT = 2;
		if (m_IsAnimationPlaying == false && isMoving == false && m_CurrentIdleFrame < M_TOTAL_IDLE_FRAMES) {
			m_CurrentIdleFrame += 1;
		}

		else if (m_CurrentIdleFrame >= M_TOTAL_IDLE_FRAMES) {
			m_CurrentIdleFrame = 0;
		}

		if (isMoving == false && m_IsAnimationPlaying == false && m_AttackMovementDirection == LEFT) {
			player.SetFrame(m_CurrentIdleFrame + M_IDLE_LEFT_STARTING_FRAME);

		}
		else if (isMoving == false && m_AttackMovementDirection == RIGHT) {
			player.SetFrame(m_CurrentIdleFrame + M_IDLE_RIGHT_STARTING_FRAME);

		}
	}


	void Player::ProgressWalkAnimation() { //the second lowest priority animation, only plays when player is just moving around
		bool isMoving = GetAsyncKeyState(VK_LEFT) || GetAsyncKeyState(VK_RIGHT) || GetAsyncKeyState(VK_UP) || GetAsyncKeyState(VK_DOWN);
		const int LEFT = 1;
		const int RIGHT = 2;
		if (isMoving && m_IsAnimationPlaying == false && m_CurrentWalkFrame < M_TOTAL_WALK_FRAMES)
		{
			m_CurrentWalkFrame += 1;
		}
		else if (m_CurrentWalkFrame >= M_TOTAL_WALK_FRAMES) {
			m_CurrentWalkFrame = 0;
		}

		if (isMoving && m_AttackMovementDirection == LEFT) {
			player.SetFrame(m_CurrentWalkFrame + M_WALKLEFT_STARTING_FRAME);

		}
		else if (isMoving && m_AttackMovementDirection == RIGHT) {
			player.SetFrame(m_CurrentWalkFrame + M_WALKRIGHT_STARTING_FRAME);

		}

	}

	void Player::StartBashLeftAnimation() {
		if (m_CurrentBashLeftFrame == 0) {
			m_CurrentBashLeftFrame = 1;
			m_IsAnimationPlaying = true;
		}

	}

	void Player::ProgressBashLeftAnimation(Surface* gameScreen) {//the second highest priority animation, will only be interupted by death
		bool isBashingLeft = m_CurrentBashLeftFrame > 0;
		if (m_CurrentBashLeftFrame < M_TOTAL_BASH_FRAMES && isBashingLeft)
		{
			m_IsAnimationPlaying = true;
			player.SetFrame(m_CurrentBashLeftFrame + M_BASH_LEFT_STARTING_FRAME);
			m_CurrentBashLeftFrame += 1;
		}

		else if (m_CurrentBashLeftFrame >= M_TOTAL_BASH_FRAMES) {
			m_CurrentBashLeftFrame = 0;
			m_IsAnimationPlaying = false;
		}


	}

	void Player::StartBashRightAnimation() {
		if (m_CurrentBashRightFrame == 0) {
			m_CurrentBashRightFrame = 1;
			m_IsAnimationPlaying = true;
		}
	}
	void Player::ProgressBashRightAnimation(Surface* gameScreen) { //the second highest priority animation, will only be interupted by death
		bool isBashingRight = m_CurrentBashRightFrame > 0;
		if (m_CurrentBashRightFrame < M_TOTAL_BASH_FRAMES && isBashingRight)
		{
			m_IsAnimationPlaying = true;
			player.SetFrame(m_CurrentBashRightFrame + M_BASH_RIGHT_STARTING_FRAME);
			m_CurrentBashRightFrame += 1;
			std::cout << "BashLeftFramePlus\n";
		}

		else if (m_CurrentBashRightFrame >= M_TOTAL_BASH_FRAMES) {
			m_CurrentBashRightFrame = 0;
			m_IsAnimationPlaying = false;
		}
	}


	void Player::StartSwipeLeftAnimation() {
		if (m_CurrentSwipeLeftFrame == 0) {
			m_CurrentSwipeLeftFrame = 1;
			m_IsAnimationPlaying = true;
		}

	}

	void Player::ProgressSwipeLeftAnimation(Surface* gameScreen) { //the second highest priority animation, will only be interupted by death
		bool isSwipingLeft = m_CurrentSwipeLeftFrame > 0;
		if (m_CurrentSwipeLeftFrame < M_TOTAL_SWIPE_FRAMES && isSwipingLeft)
		{
			m_IsAnimationPlaying = true;
			player.SetFrame(m_CurrentSwipeLeftFrame + M_SWIPE_LEFT_STARTING_FRAME);
			m_CurrentSwipeLeftFrame += 1;
		}

		else if (m_CurrentSwipeLeftFrame >= M_TOTAL_SWIPE_FRAMES) {
			m_CurrentSwipeLeftFrame = 0;
			m_IsAnimationPlaying = false;
		}


	}



	void Player::StartSwipeRightAnimation() {
		if (m_CurrentSwipeRightFrame == 0) {
			m_CurrentSwipeRightFrame = 1;
			m_IsAnimationPlaying = true;
		}

	}

	void Player::ProgressSwipeRightAnimation(Surface* gameScreen) { //the second highest priority animation, will only be interupted by death
		bool isSwipingRight = m_CurrentSwipeRightFrame > 0;
		if (m_CurrentSwipeRightFrame < M_TOTAL_SWIPE_FRAMES && isSwipingRight)
		{
			m_IsAnimationPlaying = true;
			player.SetFrame(m_CurrentSwipeRightFrame + M_SWIPE_RIGHT_STARTING_FRAME);
			m_CurrentSwipeRightFrame += 1;
		}

		else if (m_CurrentSwipeRightFrame >= M_TOTAL_SWIPE_FRAMES) {
			m_CurrentSwipeRightFrame = 0;
			m_IsAnimationPlaying = false;
		}


	}


	void Player::StartDeathAnimation() {
		if (m_CurrentDeathFrame == 0) {
			m_CurrentDeathFrame = 1;
		}
	}

	void Player::ProgressDeathAnimation() { //the highest priority animation interupts all other animations
		bool isSwipingRight = m_CurrentDeathFrame > 0;
		if (m_CurrentDeathFrame < M_TOTAL_DEATH_FRAMES && isSwipingRight)
		{
			player.SetFrame(m_CurrentDeathFrame + M_DEATH_STARTING_FRAME);
			m_CurrentDeathFrame += 1;
		}

		else if (m_CurrentDeathFrame >= M_TOTAL_DEATH_FRAMES) {
			m_CurrentDeathFrame = 0;
			UI::m_GameState = 3;
		}
		
	}


	//Getters and setters
	void Player::SetLocation(int x, int y)
	{
		m_Location[0] = x;
		m_Location[1] = y;
	}
	std::vector <int> Player::GetLocation()
	{
		return m_Location;
	}


	void Player::SetLeftBashLocation(int playerLocationX, int playerLocationY){ //also centers the attack properly
		const int LEFT_BASH_OFFSET_X = 16;
		const int LEFT_BASH_OFFSET_Y = 10;
		m_BashLocation[0] = playerLocationX - attack1.m_AttackWidth + LEFT_BASH_OFFSET_X;
		m_BashLocation[1] = playerLocationY + LEFT_BASH_OFFSET_Y;
	}
	std::vector <int> Player::GetLeftBashLocation()
	{
		return m_BashLocation;
	}

	void Player::SetRightBashLocation(int playerLocationX, int playerLocationY) { //also centers the attack properly
		const int RIGHT_BASH_OFFSET_X = 16;
		const int RIGHT_BASH_OFFSET_Y = 10;
		m_BashLocation[0] = playerLocationX + RIGHT_BASH_OFFSET_X + m_ImageWidth/2;
		m_BashLocation[1] = playerLocationY + RIGHT_BASH_OFFSET_Y;
	}

	std::vector <int> Player::GetRightBashLocation() {
		return m_BashLocation;
	}

	void Player::SetLeftSwipeLocation(int playerLocationX, int playerLocationY) { //also centers the attack properly
		const int RIGHT_SWIPE_OFFSET_X = 12;
		const int RIGHT_SWIPE_OFFSET_Y = 10;
		m_SwipeLocation[0] = playerLocationX - attack1.m_AttackWidth + RIGHT_SWIPE_OFFSET_X;
		m_SwipeLocation[1] = playerLocationY + RIGHT_SWIPE_OFFSET_Y;
	}
	std::vector <int> Player::GetLeftSwipeLocation() {
		return m_SwipeLocation;
	}

	void Player::SetRightSwipeLocation(int playerLocationX, int playerLocationY) { //also centers the attack properly
		const int RIGHT_SWIPE_OFFSET_X = 20;
		const int RIGHT_SWIPE_OFFSET_Y = 10;
		m_SwipeLocation[0] = playerLocationX + RIGHT_SWIPE_OFFSET_X + m_ImageWidth / 2;
		m_SwipeLocation[1] = playerLocationY + RIGHT_SWIPE_OFFSET_Y;
	}

	std::vector <int> Player::GetRightSwipeLocation() {
		return m_SwipeLocation;
	}


	void Player::SetCurrentHealth(float currentHealth) {
		m_CurrentHealth = currentHealth;
	}

	float Player::GetCurrentHealth() {
		return m_CurrentHealth;
	}

	void Player::SetMaxHealth(float maxHealth) {
		m_MaxHealth = maxHealth;
	}

	float Player::GetMaxHealth() {
		return m_MaxHealth;
	}


	void Player::SetIsDead(bool isDead)
	{
		m_IsDead = isDead;
	}
	bool Player::GetIsDead()
	{
		return m_IsDead;
	}


	void Player::SetIsAttackColliding(bool isAttackColliding)
	{
		m_IsAttackColliding = isAttackColliding;
	}
	bool Player::GetIsAttackColliding()
	{
		return m_IsAttackColliding;
	}

}