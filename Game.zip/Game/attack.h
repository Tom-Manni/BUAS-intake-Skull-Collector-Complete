#pragma once
#include <string>
#include <algorithm>
#include <vector>
#include "game.h"
#include "surface.h"

namespace Tmpl8 {
	class Attack {
	public:
		Attack(int attackHeight = 50, int attackWidth = 50, int frame = 0);
		~Attack();

		int m_AttackHeight;
		int m_AttackWidth;

	private:

		int m_Frame;
		bool m_IsColliding;

	};
}