#include <vector>
#include <stdlib.h>
#include <windows.h>
#include "game.h"
#include "surface.h"
#include "attack.h"
#include "player.h"

#include <iostream>




namespace Tmpl8 {
	//constructor
	Attack::Attack(int attackHeight, int attackWidth, int frame) :
		m_AttackHeight(attackHeight), m_AttackWidth(attackWidth), m_Frame(frame)
	{
	}

	//destructor
	Attack::~Attack() {
	}
}

