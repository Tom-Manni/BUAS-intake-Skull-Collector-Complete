#pragma once
#include <vector>
#include "game.h"
#include "surface.h"
#include "player.h"
#include "exit.h"


namespace Tmpl8 {
	class Player;
	class Object;
	class UI;

	class Enemy {
	public:
		Enemy(int imageHeight = 96, int imageWidth = 80, int frame = 0, int speed = 1, float invincibilitySecs = 1.0f, float iFrameTimer = 0.0f, 
			int lastMovementDirection = 2, int currentWalkFrame = 0,
			std::vector<int> location = { 100, 100 }, bool isHit = false, bool isAlive = false, bool isInvincible = false, int spriteOffsetX = 48, 
			int spriteOffsetY = 64);
		~Enemy();

		void RunAway(Surface* gameScreen, float deltaTime, Player& playerReference);
		void Spawn(Surface* gameScreen, Object* bush);
		void Escape(Surface* gameScreen);
		int CheckQuadrant(Surface* gameScreen);
		void Die();
		void ProgressWalkAnimation();

		void ResetBomber();

		void SetLocation(int x, int y);
		std::vector <int> GetLocation();

		void SetIsAlive(bool isAlive);
		bool GetIsAlive();

		void SetIsInvincible(bool isInvincible);
		bool GetIsInvincible();

		void SetInvincibilitySecs(float InvincibilitySecs);
		float GetInvincibilitySecs();

		void SetIFrameTimer(float iFrameTimer);
		float GetIFrameTimer();


		int m_ImageHeight;
		int m_ImageWidth;

		int m_SpriteOffsetX;
		int m_SpriteOffsetY;

		static const int M_TOTAL_WALK_FRAMES;
		static const int M_WALK_LEFT_STARTING_FRAME;
		static const int M_WALK_RIGHT_STARTING_FRAME;

		static const int LEFT;
		static const int RIGHT;

	private:

		
			
		int m_Frame;
		int m_Speed;
		int m_LastMovementDirection;
		int m_CurrentWalkFrame;

		float m_IFrameTimer;
		float m_InvincibilitySecs;
		bool m_IsHit;
		bool m_IsAlive;
		bool m_IsInvincible;
		static int m_Count;
		std::vector<int> m_Location;


		Sprite bomber;

	};
}