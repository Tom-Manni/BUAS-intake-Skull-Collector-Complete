#include "exit.h"


namespace Tmpl8 {
	//these are the center points of the exits -15 pixels off the end. Assuming window size is 800x512
	const int Exit::M_EXIT_WIDTH = 60;
	const int Exit::M_EXIT_HEIGHT = 50;
	const std::vector <int> Exit::M_EXIT_LEFT = { 15,256 };
	const std::vector <int> Exit::M_EXIT_RIGHT = { 785,256 };
	const std::vector <int> Exit::M_EXIT_TOP = { 400,15 };
	const std::vector <int> Exit::M_EXIT_BOTTOM = { 400,497 };
}
