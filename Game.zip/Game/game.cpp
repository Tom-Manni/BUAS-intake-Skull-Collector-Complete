#include "game.h"
#include "surface.h"
#include "object.h"
#include "player.h"
#include "enemy.h"
#include "ui.h"
#include <cstdio> //printf
#include <windows.h>
#include <stdlib.h>
#include <algorithm>


#include <iostream>


namespace Tmpl8
{
	//create timer
	float gameTimer = 0.0f;
	float attackTimer = 0.0f;
	float animationTimer = 0.0f;

	//create the UI, player and the bushes
	UI baseUI;
	Player player1;

	Object bush1;
	Object bush2;
	Object bush3;
	Object bush4;
	Object bush5;

	Enemy bomber1;





	void Game::Init()
	{
		DWORD seed = GetTickCount();
		srand(seed);

		//add pointers to a vector for use in functions
		Object::bushesPtr.push_back(&bush1);
		Object::bushesPtr.push_back(&bush2);
		Object::bushesPtr.push_back(&bush3);
		Object::bushesPtr.push_back(&bush4);
		Object::bushesPtr.push_back(&bush5);
	}
	

	void Game::Shutdown()
	{
	}
	

	void Game::Tick(float deltaTime)
	{
		switch (UI::m_GameState) { //show opening screen
		case 1:
			baseUI.StartGame(screen,player1);
			player1.ResetStats();
			player1.ResetPlayer();
			bomber1.ResetBomber();
			break;

		case 2:  //Run main loop
			//sets timers
			gameTimer += (deltaTime / 1000);
			animationTimer += (deltaTime / 1000);

			if (gameTimer > (1 / 60)) {
				//reset screen and overlay background/UI
				screen->Clear(0);
				baseUI.background.Draw(screen, 0, 0);
				baseUI.healthBar.Draw(screen, 0, 0);

				//spawn player once
				player1.SpawnIfNotSpawned(screen, screen->GetWidth() / 2, screen->GetHeight() / 2);

				//draw bushes at random locations within bounds
				Object::DrawAll(screen, baseUI);

				//Player health admin
				player1.DrainHealth(deltaTime, baseUI);
				baseUI.UpdateHealthBar(baseUI.healthBar, player1);

				//player inputs
				player1.CheckPlayerMoveInput(screen, baseUI, deltaTime);
				player1.CheckPlayerAttackInput(screen, Object::bushesPtr, bomber1, baseUI);

				//enemy movement AI
				bomber1.RunAway(screen, deltaTime, player1);

				//Progress animations
				if (animationTimer > 0.15) {

					player1.ProgressAllPlayerAnimations(screen);

					bomber1.ProgressWalkAnimation();


					animationTimer = 0;
				}

				//reset timer
				gameTimer = 0;
			}

			break;
		
		case 3: //show game over screen, prompt player to restart
			baseUI.DisplayGameOver(screen,player1);
			break;
		}
		
	}
};